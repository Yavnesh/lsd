# LSD (Learn Something Daily) - Project Overview

## 🧠 Core Philosophy
LSD is a gamified, micro-learning platform designed to make complex concepts from psychology, sociology, and modern life highly accessible and engaging. Instead of reading textbooks, users swipe through "viral-style" meme content, hooks, and quizzes.

## 🏗️ Architecture & Technology Stack
- **Framework:** Next.js 16 (Turbopack)
- **Styling:** Tailwind CSS v4, Framer Motion (Animations), Lucide React (Icons)
- **Database:** SQLite (`dev.db`) mapped via Prisma ORM v6.4.1
- **Authentication:** NextAuth.js (configured closely with Google OAuth)
- **State Management:** Zustand (for client-side UI hydration syncing)
- **Theme:** `next-themes` mapping to Tailwind custom roots for Dark/Light mode integration.

## 🗄️ Database Schema & Relationships (Prisma)
We have heavily separated concerns to keep Authentication separated from Gamification:
1. **User / Account / Session:** The backbone NextAuth tables.
2. **UserStat (1:1 with User):** Stores the user's `xp`, `streak`, and `level` rank.
3. **Topic:** Centralized repository defining what users learn. It contains title, summary, type (DAILY, HUB), and JSON payloads for block rendering.
4. **UserActivity (M:N mapping):** Connects a User and a Topic. Stores timestamp metrics to record precisely when users completed topics, and guarantees they only earn XP once per topic.
5. **Quest & UserQuest:** A scalable Quest system for daily milestones.
6. **Trophy & UserTrophy:** Badge unlocks mapped to specific user milestones.

## 🔐 Authentication Flow
1. User clicks "Continue with Google".
2. NextAuth handles the OAuth Handshake, successfully storing the user in the SQLite `User` database.
3. A Prisma trigger `createUser` callback automatically fires via NextAuth:
   - A generic fallback `defaultAvatar` is generated dynamically using DiceBear Bottts based on the user's Google Name. 
   - 6 visually distinct alternative `suggestedAvatars` are cached.
   - A `UserStat` blank state is explicitly constructed for the user with 0 XP. 
4. The user is globally logged into the UI, dynamically fetching their `xp` score from their mapped `session()`.

## 🌐 The User Interface (UI/UX)
- **Landing Page (`/`):** A public-facing marketing page emphasizing the 1% smarter value proposition.
- **Navbar:** Dynamic layout sensing `useSession()`. Shows Light/Dark modes, "My Stats", and the User's selected DiceBear avatar menu securely.
- **Learn Daily (`/learn`):** The core product. A single large, scrollable gradient view loading Hook Blocks, Memes, and Polling Components securely validating user state before granting +50 XP via `useUserStore`.
- **Dashboard (`/dashboard`):** Maps the user's real `.stat` level globally across detailed XP progress bars and a mock historical Activity Feed timeline.

## 🛠 Next Steps
- Implement backend Prisma logic exclusively hooking `userActivity` insertions so completing the UI triggers the DB to grant XP permanently. 
- Build a generic CMS to rapidly spin up `Topics` locally. 
